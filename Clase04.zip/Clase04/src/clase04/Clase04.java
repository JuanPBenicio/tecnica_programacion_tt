/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author juanp
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Operador de concatenacion.
        
        String nombre = "Marcelo";
        String apellido = "Loppez";
        
        //System.out.println(nombre + " " + apellido);
        //System.out.println("El nombre es:" + nombre);
        
        //pasar de String a Mayusculas
        // toUpperCase();
        //System.out.println(nombre.toUpperCase());
        // imprime la variable en mayuscula, pero la variable sigue igual.
        //System.out.println(nombre);
        
        // modificar la variable 
        //nombre = nombre.toUpperCase();
        //System.out.println(nombre);
        
        // pasar String a minuscula.
        //toLowerCase().
        //System.out.println(nombre.toLowerCase());
        // imprime la variable en minuscula, pero la variable sigue igual
        //System.out.println(nombre);
        
        nombre = nombre.toLowerCase();
        System.out.println(nombre);
        
        /*
            Imprimir por consola la frase: "A Cuesta le cuesta subir la cuesta y
            en medio de la cuesta, va y se acuesta.
        */
        
        char palabra1= 'A';
        String palabra2 = "cuesta";
        String palabra3 = "le";
        String palabra4 = "cuesta";
        String palabra5 = "subir";
        String palabra6 = "la";
        String palabra7 = "cuesta";
        char palabra8 = 'y';
        String palabra9 = "en";
        String palabra10 = "medio";
        String palabra11 = "de";
        String palabra12 = "la";
        String palabra13 = "cuesta";
        char palabra14 = 44;
        String palabra15 = "va";
        char palabra16 = 'y';
        String palabra17 = "se";
        String palabra18 = "acuesta";
        
        
        System.out.println(palabra1 + " " + 
                palabra2.substring(0, 1).toUpperCase() + 
                palabra2.substring(1) + " " + palabra3 + " " + 
                palabra4 + " " + palabra5 + " " + palabra6 + " " + palabra7 + 
                " " + palabra8 + " " + palabra9 + " " + palabra10 + " " + 
                palabra11 + " " + palabra12 + " " + palabra13 + palabra14 + " " +
                palabra15 + " " + palabra16 + " " + palabra17 + " " + palabra18 
                + ".");
        
             
    }
}
