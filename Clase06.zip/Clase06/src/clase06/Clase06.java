/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase06;

/**
 *
 * @author juanp
 */
public class Clase06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //System.out.println("Hola Mundo!!");
        
         /*Operadores logicos */
         /*
            & and
            | Or
            ! not
            El resultado es Booleano.
         */
         /*
         boolean log1 = true;
         boolean log2 = false;
         
         System.out.println("AND &: ");
         System.out.println(log1 && log2);
         
         System.out.println("OR || ");
         System.out.println(log1 || log2);
         
         System.out.println("Not !");
         System.out.println(!log1);
         System.out.println(!log2);
         Al utilizar un solo operador, se evaluan todas las condiciones.
         Al utilizar dos operadores, si con la primera condicion.
         se determina el valor de verdad, no evalua las siguientes. 
         */
         
         /* 1) Dados n1=5, n2=10 y n3=20. informar
            n1 + n2
            n3 - n1
            n1 * n3
            n1 / n2
         */
         
         int n1 = 5, n2=10, n3=20;
         int resultadoSuma, resultadoResta, resultadoMultiplicacion, 
                 resultadoDivision;
         
         resultadoSuma = n1 + n2;
         resultadoResta = n3 - n1;
         resultadoMultiplicacion = n1 * n3;
         resultadoDivision = n1 / n2;
         
         //System.out.println("El resultado de la suma es " + resultadoSuma);
         
         //System.out.println("El resultado de la resta es " + resultadoResta);
         
         //System.out.println("El resultado de la multiplicacion es " + 
           //      resultadoMultiplicacion);
         
         //System.out.println("El resultado de la division es " + 
            //     resultadoDivision);
         
         

        // 2) Dados n1=10, n2=20 y n3=30. Informar:
         /*
            a) El total de la suma de todas la variable.
            b) El promedio
            c) El resto entre n2 y n1
         */
         
         n1 = 10; 
         n2 = 20; 
         n3 = 30;
         int resultadoTotal;
         int promedio;
         int resto;
         
         resultadoTotal = n1 + n2 + n2;
         promedio = resultadoTotal / 3;
         resto = n2 % n3;
         
         //System.out.println("La suma de las variable es " + resultadoTotal);
         //System.out.println("El promedio es " + promedio);
         //System.out.println("El resto de n2 y n3 es " + resto);
         
         
         
         /*3) Declarar dos variables n1=5 y n2=10.
            
            Utilizando concatenacion entre las variables y los literales,
            mostrar en pantalla la siguiente expresion.
            n1 es igual a 5, n2 es igual a 10 y n1 mas n2 es igual a 15.   
         */
         
         n1 = 5;
         n2 = 10;
         int suma = n1 + n2;
         
         //System.out.println("n1 mas n2 es igual a " + suma);
         
         
         
         /*
            4) Haciendo uso de la constante IVA = 21, calcular el precio con IVA
            de los siguientes productos e informa:
            
            a) remera: $59.90.
            b) pantalon: $99.90.
            c) campera: $149.90.
         */
         
         final int iva= 21;
         double precioRemera = 59.90;
         double precioPantalon = 99.90;
         double precioCampera = 149.90;
         
         double precioFinalRemera;
         double precioFinalPantalon;
         double precioFinalCampera;
         
         precioFinalRemera = precioRemera + (precioRemera*iva/100);
         precioFinalPantalon = precioPantalon + (precioPantalon*iva/100);
         precioFinalCampera = precioCampera + (precioCampera * iva / 100);
         
         //System.out.println("El precio final de la remera es " + 
                // precioFinalRemera);
         
        //System.out.println("El precio final del pantalon es " + 
                //precioFinalPantalon);
        
        //System.out.println("El precio final de la campera es " + 
                //precioFinalCampera);
    }    
}
