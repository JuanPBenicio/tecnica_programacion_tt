package trabajopracticofinal;

import java.util.Scanner;

public class Ejercicio1 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        // Declaracion e inicializacion de variable
        int nota_alumnos[] = new int [3];
        int suma = 0;
        int promedio = 0;
        int contador_nota = 0;
        int opcion;
        
        
        //calcularPromedio(nota_alumnos, suma, contador_nota, promedio);
       
        // El bucle nos permite ejecutar el menu, hasta que el usuario elige sa-
        // lir (opcion 0).
        
        
        do{
            System.out.println("Ingrese la opcion deseada:");
            System.out.println("1) Ingresar notas.");
            System.out.println("2) Mostrar el promedio.");
            System.out.println("0) Salir");
            opcion = teclado.nextInt();

            switch(opcion){
                case 0:
                    System.out.println("Ha solicitado salir del programa");
                break;

                case 1:
                    ingresarNota(teclado, nota_alumnos);
                break;

                case 2:
                    for(int i=0; i<nota_alumnos.length; i++){
                        suma += nota_alumnos[i];
                        contador_nota ++;
                    }
                    promedio = suma / contador_nota;
                    System.out.println("El promedio es " + promedio);
                    
                    aprobado(promedio);
                    recuperatorio(promedio, nota_alumnos);
                    noAprobado(promedio, nota_alumnos);
                break;

                default:
                    System.out.println("Opcion invalida");
                break;
            }
        }
        while(opcion != 0);
        
    }
    
    /**
     * Este procedimiento nos permite ingresar datos, en el arreglo nota_alumnos
     * @param tecla 
     * @param nota es el arreglo donde se almacena las notas de los alumnos.
     */
    public static void ingresarNota(Scanner tecla, int nota[]){
        System.out.println("A continuacion se la va ha solicitar 3 notas");
        for(int i=0; i<nota.length; i++){
            System.out.print("Ingrese una nota: ");
            nota[i] =  tecla.nextInt();
        }
    }
    
    /**
     * Este procedimiento segun el promedio, si es mayor a 6, muestre un determi-
     * nado mensaje.
     * @param promedio es una variable donde sa aloja el valor del promedio de 
     * notas.
     */
    public static void aprobado(int promedio){
        if(promedio >= 6){
            System.out.println("APROBADO");
        }
    }
    
    /**
     * Este procedimiento verifica si el promedio es menor o igual a 3
     * @param promedio variable donde se almacena promedio, el cual nos permite ve-
     * rificar si el promedio es menor o igual a 3.
     * @param nota_alum  con el array voy preguntando por cada posicion si es me-
     * nor a 3.
     */
    public static void noAprobado(int promedio, int nota_alum[]){
        if(nota_alum[0] <=3 || nota_alum[1] <=3 || nota_alum[2] <=3){
            if(promedio <6){
                System.out.println("No Aprobado");
            }
        }
    }
    
    /**
     * Este procedimiento verifica si el promedio es mayor o igual a 4 y menor o
     * igual a 5.
     * @param promedio variable donde se almacena promedio, el cual nos permite
     * verificar si el promedio esta entre 4 y 5.
     * @param nota_alumno con el array voy preguntando ´por cada posicion si es 
     * meyor a 3 y menor a 6.
     */
    public static void recuperatorio(int promedio, int nota_alumno[]){
        if((nota_alumno[0] >3 && nota_alumno[0] <6) || 
                (nota_alumno[1] >3 && nota_alumno[1] <6) || 
                (nota_alumno[2] >3 && nota_alumno[2] <6)){
            if(promedio < 6){
                System.out.println("Recuperatorio");
            }
        }
    }
}
