/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase05;

/**
 *
 * @author juanp
 */
public class Clase05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //metodo para extraer una subcadena.
        String palabra = "Programacion";
        
        //cada caracter ocupa un lugar de posicion.
        // las posiciones comienzan en 0.
        String subPalabra = palabra.substring(3);
        // el numero que va dentro de los parentesis indica la posicion,
        // desde donde se extraera la sub-cadena
        System.out.println(subPalabra);
        
        String subPalabra2 = palabra.substring(6,7);
        // en este caso indicamos desde donde u hasta donde queremos extraer 
        //la sub-cadena.
        System.out.println(subPalabra2);
        
        // Operadores aritmeticos.
        /*
            + suma
            - resta
            * multiplicacion
            / division
            % modulo o resto de la division.
            son operadores binarios porque necesitan 2 operandos.
            Los operandos son numericos y el resultado es numerico.
        */
        int numero1 = 10;
        int numero2 = 2;
        
        System.out.println("Suma");
        System.out.println(numero1 + numero2);
        
        System.out.println("Resta");
        System.out.println(numero1 - numero2);
        
        System.out.println("Multiplicacion");
        System.out.println(numero1 * numero2);
        
        System.out.println("Division");
        System.out.println(numero1 / numero2);
        
        System.out.println("Modulo o resto de la division");
        System.out.println(numero1 % numero2);
        
        // Operadores de asignacion.
        /*
            = igual (de asignacion)
            += suma y asignacion
            -= resta y asignacion
            *= multiplicacion y asignacion
            /= division y asignacion
            %= modulo y asignacion.
            Son operadores.
            Asignan el valor a una variable y se la modican utilizando una ex-
            presion. 
        */
        
        System.out.println(numero1);
        numero1 = 12; // con el = se le asigna el valor que esta a la derecha.
        
        System.out.println(numero1);
        
        numero1 += 2; // sumo 2 al valor de la variable y le asigno ese valor,
                     // es lo mismo que: numero1 = numero1 + 2;
        
        System.out.println(numero1);
        
        numero1 -= 2;
        // resto 2 al valor de la variable y le asigno ese valor, es lo mismo
        // que: numero1 = numero1  - 2;
        System.out.println(numero1);
        
        numero1 *= 2;
        // multiplico por 2 el valor de la variable y le asigno ese valor, es lo
        // mismo que: numero1= numero1*2;
        System.out.println(numero1);
        
        numero1 /= 2;
        // dividido por 2 el valor de la variable y le asigno ese valor es lo 
        // mismo que: numero1 = numero1 / 2;
        System.out.println(numero1);
        
        numero1 %=2;
        // obtiene el modulo de la division entre la variable y el 2 y le asigno
        // ese valor a la variable es lo mismo que: numero1 = numero1%2;
        System.out.println(numero1);
        
        //Operador incrementales y decrementales.
        /*
            ++ incrementa el valor en 1
            -- decrementa el valor en 1
            Son operadores unarios, trabajan con un solo operador.
        */
        
        numero1 ++; // incrementa en 1 el valor de la variable
        // es lo mismo que: numero1 = numero1 + 1 o lo mismo que: n
        
        // operadores relacionales
        /*
            > mayor
            < menor
            >= mayor o igual
            <= menor o igual
            != distinto
            Son operadores binarios.
            Los operadores son numericos y el resultado es booleano.
        */
        numero1 = 15;
        numero2 = 20;
        
        System.out.println(numero1 > numero2); //
        System.out.println(numero1 < numero2); // true
        
    }
}
