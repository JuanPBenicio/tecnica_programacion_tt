/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase03;

/**
 *
 * @author juanp
 */
public class Clase03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //System.out.println("Hola mundo!!");
        //
        //boolean: ocupa 1 byte y almacena 2 valores (0y1)
        // que representan true u false.
        
        //boolean L = true;    
        // representa el valor de verdad
        
        //boolean m = false;  
        // representa el valor de falsedad. 
        
        //System.out.println(L);
        //System.out.println(m);
        
        // char: ocupa 2 bytes, almacena un entero que representa un caracter 
        // de la tabla unicode. Unicode es un standard de codificacion de carac-
        //teres a nivel mundial.
        //char n = 65; // almacena el entero 65.        
        
        //System.out.println(n);
        
        //n += 32;
        //System.out.println(n);
        
        //n = 'f';
        //System.out.println(n);
        
        //string no es un tipo de dato primitivo, representa una cadena de caracteres
        String o = "Hola, soy una cadena de caracteres."; // se escribe con S mayuscula 
        System.out.println(o);
        
        // constante
        final int qw = 10;
        
        System.out.println(qw);
        
        // las constantes deben llevar la palabra reservada final y el nombre
        // de la constante va en mayuscula por convencion. 
        
        // tipo de dato var
        // en este tipo de datos el verdadero tipo de dato asignado.
        // 
        var nombre = "Juan";
        
        //System.out.println(nombre);
        
        //System.out.println("hello wordl!!"); 
        
        
        /*
            Imprimir por consola la frase: "A Cuesta le cuesta subir la cuesta
            y en medio de la cuesta, va y se acuesta.
        */
        
        char palabra1 = 65;
        String palabra2 = "cuesta";
        String palabra3 = "le";
        String palabra4 = "cuesta";
        String palabra5 = "subir";
        String palabra6 = "la";
        String palabra7 = "cuesta";
        char palabra8 = 121;
        String palabra9 = "en";
        String palabra10 = "medio";
        String palabra11 = "de";
        String palabra12 = "la";
        String palabra13 = "cuesta";
        char palabra14 = 44;
        String palabra15 = "va";
        char palabra16 = 121;
        String palabra17 = "se";
        String palabra18 = "acuesta";
        
        System.out.println(palabra1 + " " + palabra2 + " " + palabra3 + " " +
                palabra4 + " " + palabra5 + " " + palabra6 + " " + palabra7 +
                " " + palabra8 + " " + palabra9 + " " + palabra10 + " " +palabra11
                +" " + palabra12 + " " + palabra13 + palabra14 + 
                " " + palabra15 + " " + palabra16 + " " + palabra17 + " " +
                palabra18);
    }
}
