/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase02;

/**
 *
 * @author juanp
 */
public class Clase02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //int a = 2;
        //int b = 34;
        //int resultado = a + b;
        //System.out.println("La suma entre a y b es " + resultado);
        
        // el byte ocupa 1 byte y representa un numero entero.
        // entre -128 y 127
        //byte f = 100;
        //System.out.println(f);
    
        // tipo de dato Short: ocupa 2 bytes y representa un entero
        // entre - 32.768 y 32.767
        
        //short e = 32100;
        //System.out.println(e);
        
        // int: ocupa 4 byte y representa un entero.
        // entre -2.147.483.648 y 2.147.483.647
        
        //int r= 4000000;
        //System.out.println(r);
        
        //long: ocupa 8 byte y representa un valor entero. 
        // en un valor muy grande no tan utilizado.
        
        //long i = 112345678901011L;
        //System.out.println(i);
        
        //Float: ocupa 4 byte y tiene una precision de 32 bits
        //float g = 14.23F;
        //System.out.println(g);
        
        //double: ocupa 8 byte y tiene una presion de 64 bits
        //double j= 23.12;
        //System.out.println(j);
        
        //diferencia de precision entre float y double
        float fl = 10f;
        double dl = 10;
        
        System.out.println(fl / 3);
        System.out.println(dl / 3);
        
    }
    
}
